/* Shared UI atoms — used across mobile + desktop */
const { useState, useEffect, useRef } = React;

// ─── Paper Doc Placeholder ─────────────────────────────────────
function PaperDoc({ w = '75%', tint = 'paper', lines = 8, rotate = 0, children }){
  const bg = tint === 'mint' ? 'var(--mint-wash)' :
             tint === 'dark' ? '#2a342d' : '#fff';
  const col = tint === 'dark' ? 'rgba(255,255,255,0.3)' : 'var(--line-soft)';
  return (
    <div style={{
      width:w, aspectRatio:'0.72', background:bg,
      boxShadow:'0 3px 10px rgba(31,42,36,0.12)',
      padding:'16px 14px', position:'relative',
      transform:`rotate(${rotate}deg)`,
      border:'1px solid var(--line-soft)',
    }}>
      {Array.from({length:lines}).map((_,i) => (
        <div key={i} style={{
          height:'6px', width: [95,80,65,90,85,60,92,75][i%8]+'%',
          background:col, opacity:0.5, borderRadius:'2px',
          marginBottom:'9px',
        }}/>
      ))}
      {children}
    </div>
  );
}

// ─── Cropping corners overlay ──────────────────────────────────
function CropCorners({ color = 'var(--mint-3)' }){
  const c = { position:'absolute', width:'14px', height:'14px', background:color,
    border:'2px solid #fff', borderRadius:'50%', cursor:'grab' };
  return (
    <>
      <span style={{...c, top:-7, left:-7}}/>
      <span style={{...c, top:-7, right:-7}}/>
      <span style={{...c, bottom:-7, left:-7}}/>
      <span style={{...c, bottom:-7, right:-7}}/>
      <div style={{position:'absolute', inset:0, border:`2px dashed ${color}`, pointerEvents:'none'}}/>
    </>
  );
}

// ─── Page thumbnail (shows filter effect mock) ─────────────────
function PageThumb({ page, active, onClick, onRemove, idx }){
  const map = {
    auto:{bg:'#fff', tint:'#4ea07c'},
    scan:{bg:'#f8f8f4', tint:'#2a2a2a'},
    color_doc:{bg:'#fff', tint:'#b25a4a'},
    document:{bg:'#f2f0ea', tint:'#3d4b42'},
    enhance:{bg:'#fff', tint:'#6b8aa3'},
    bw:{bg:'#f0f0f0', tint:'#1f2a24'},
    original:{bg:'#fdfbf2', tint:'#6b766e'},
  };
  const m = map[page.filter] || map.auto;
  return (
    <div onClick={onClick} style={{
      position:'relative', cursor:'pointer',
      border: active ? '2px solid var(--mint-3)' : '1.25px solid var(--line-soft)',
      borderRadius:'6px', padding:'4px',
      background: active ? 'var(--mint-wash)' : 'var(--paper)',
    }}>
      <div style={{aspectRatio:'0.72', background:m.bg, padding:'6px', border:'1px solid #e0dcc8', transform:`rotate(${page.rotation}deg)`, transition:'transform 0.2s'}}>
        {[90,70,60,85,75,50].map((w,i) => (
          <div key={i} style={{height:'3px', width:w+'%', background:m.tint, opacity:0.5, marginBottom:'4px', borderRadius:'1px'}}/>
        ))}
      </div>
      <div style={{fontSize:'10px', textAlign:'center', marginTop:'4px', fontFamily:'var(--font-label)', color: active ? 'var(--mint-4)' : 'var(--ink-3)'}}>頁 {idx + 1}</div>
      {onRemove && (
        <button onClick={(e) => {e.stopPropagation(); onRemove();}} style={{
          position:'absolute', top:'-6px', right:'-6px',
          width:'18px', height:'18px', borderRadius:'50%',
          background:'var(--danger)', color:'#fff', fontSize:'10px',
          border:'2px solid var(--paper)', lineHeight:1,
        }}>×</button>
      )}
    </div>
  );
}

// ─── Filter Scroller ──────────────────────────────────────────
function FilterStrip({ selected, onChange, inverted }){
  const filters = window.filterList;
  return (
    <div style={{display:'flex', gap:'8px', overflowX:'auto', padding:'4px 0', scrollbarWidth:'thin'}}>
      {filters.map(f => {
        const on = selected === f.id;
        return (
          <button key={f.id} onClick={() => onChange(f.id)} style={{
            flex:'0 0 auto', padding:'6px 12px', borderRadius:'8px',
            border: inverted ? '1px solid rgba(255,255,255,0.3)' : '1.25px solid var(--line)',
            background: on ? (inverted ? '#fff' : 'var(--mint-3)') : (inverted ? 'rgba(0,0,0,0.4)' : 'var(--paper)'),
            color: on ? (inverted ? '#000' : '#fff') : (inverted ? '#fff' : 'var(--ink)'),
            fontSize:'12px', display:'flex', alignItems:'center', gap:'4px',
          }}>
            <span>{f.icon}</span><span>{f.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ─── Doc Type Badge ────────────────────────────────────────────
function DocTypeBadge({ type, confidence }){
  const t = window.docTypes[type] || window.docTypes.other;
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:'6px',
      padding:'4px 10px', borderRadius:'999px',
      background:`${t.color}20`, border:`1px solid ${t.color}`, color:t.color,
      fontSize:'11px', fontFamily:'var(--font-label)', letterSpacing:'0.04em',
    }}>
      <span>{t.icon}</span><span>{t.label}</span>
      {confidence != null && <span style={{opacity:0.7, fontSize:'10px'}}>{Math.round(confidence*100)}%</span>}
    </span>
  );
}

// ─── Contact Tile ──────────────────────────────────────────────
function ContactTile({ contact, selected, onClick, onFav, compact }){
  const initials = contact.name.slice(-2);
  return (
    <div onClick={onClick} style={{
      position:'relative', cursor:'pointer',
      padding: compact ? '8px 10px' : '12px',
      borderRadius:'10px',
      background: selected ? 'var(--mint-wash)' : 'var(--paper)',
      border: selected ? '1.5px solid var(--mint-3)' : '1.25px solid var(--line-soft)',
      transition:'all 0.15s',
      display:'flex', alignItems:'center', gap:'10px',
    }}>
      <div style={{
        width: compact ? '32px':'38px', height: compact?'32px':'38px',
        borderRadius:'50%',
        background: selected ? 'var(--mint-3)' : 'var(--mint-wash)',
        color: selected ? '#fff' : 'var(--mint-4)',
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontFamily:'var(--font-hand)', fontWeight:700, fontSize: compact?'14px':'16px',
        flexShrink:0,
        border: selected ? '1.5px solid var(--mint-3)' : '1.25px solid var(--mint-3)',
      }}>{initials}</div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{fontSize: compact?'13px':'14px', fontWeight:500, color:'var(--ink)'}}>{contact.name}</div>
        <div style={{fontSize:'11px', color:'var(--ink-3)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>
          {contact.dept} · {contact.title}
        </div>
      </div>
      {selected ? (
        <div style={{color:'var(--mint-3)', fontSize:'18px'}}>✓</div>
      ) : onFav ? (
        <button onClick={(e) => {e.stopPropagation(); onFav();}} style={{fontSize:'14px', opacity:contact.fav ? 1 : 0.3}}>
          {contact.fav ? '★' : '☆'}
        </button>
      ) : null}
    </div>
  );
}

// ─── Camera mock (animated viewfinder) ─────────────────────────
function CameraView({ onCapture, detected }){
  return (
    <div style={{position:'absolute', inset:0}}>
      <div className="cam-bg" style={{position:'absolute', inset:0}}/>
      {/* doc detection outline */}
      {detected && (
        <div style={{position:'absolute', top:'18%', left:'18%', right:'18%', bottom:'18%',
          border:'2px dashed var(--mint)', background:'rgba(159,213,186,0.05)', borderRadius:'2px',
        }}>
          {['top left','top right','bottom left','bottom right'].map((pos, i) => {
            const s = { position:'absolute', width:'14px', height:'14px',
              border:'2px solid var(--mint)', background:'#fff' };
            if(pos.includes('top')) s.top = -8;
            else s.bottom = -8;
            if(pos.includes('left')) s.left = -8;
            else s.right = -8;
            return <span key={i} style={s}/>;
          })}
        </div>
      )}
      {/* grid */}
      <div style={{position:'absolute', inset:0, pointerEvents:'none',
        backgroundImage:'linear-gradient(rgba(255,255,255,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.08) 1px, transparent 1px)',
        backgroundSize:'33.33% 33.33%', opacity:0.5,
      }}/>
    </div>
  );
}

// ─── Toasts ────────────────────────────────────────────────────
function Toasts({ toasts }){
  return (
    <div className="toast-host">
      {toasts.map(t => (
        <div key={t.id} className={`toast ${t.kind}`}>{t.msg}</div>
      ))}
    </div>
  );
}

// ─── Expose ───────────────────────────────────────────────────
Object.assign(window, {
  PaperDoc, CropCorners, PageThumb, FilterStrip, DocTypeBadge,
  ContactTile, CameraView, Toasts,
});
