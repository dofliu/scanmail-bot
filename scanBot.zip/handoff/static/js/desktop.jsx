/* Desktop shell — productivity workspace view */
const { useState: dUseState } = React;

function DesktopShell(){
  const [state, store] = window.useStore();
  const view = state.dView;

  const renderView = () => {
    switch(view){
      case 'dashboard': return <DDashboard/>;
      case 'scan': return <DScan/>;
      case 'contacts': return <DContacts/>;
      case 'history': return <DHistory/>;
      case 'tools': return <DTools/>;
      case 'settings': return <DSettings/>;
      default: return <DDashboard/>;
    }
  };

  return (
    <div className="desktop">
      <DSidebar view={view} onChange={store.dSetView}/>
      <div className="d-main">
        <DTopbar/>
        <div className="d-content">
          {renderView()}
        </div>
      </div>
      <Toasts toasts={state.toasts}/>
    </div>
  );
}

function DSidebar({ view, onChange }){
  const items = [
    {id:'dashboard', ic:'⌂', label:'儀表板'},
    {id:'scan', ic:'📷', label:'掃描郵寄', primary:true},
    {id:'contacts', ic:'👥', label:'聯絡人'},
    {id:'history', ic:'🕒', label:'寄件歷史'},
    {id:'tools', ic:'🛠', label:'工具箱'},
    {id:'settings', ic:'⚙', label:'設定'},
  ];
  return (
    <aside className="d-sidebar">
      <div style={{padding:'18px 22px 14px', borderBottom:'1.25px solid var(--line-soft)'}}>
        <div className="hand" style={{fontSize:'22px', fontWeight:700, lineHeight:1, color:'var(--ink)'}}>
          ScanMail<span style={{color:'var(--mint-3)'}}>+</span>
        </div>
        <div style={{fontSize:'10px', color:'var(--ink-3)', marginTop:'2px', letterSpacing:'0.1em', fontFamily:'var(--font-label)'}}>DESKTOP · v2.0</div>
      </div>

      <nav style={{padding:'14px 10px', flex:1}}>
        <div className="label" style={{padding:'0 12px 6px'}}>工作流</div>
        {items.map(it => (
          <div key={it.id} onClick={() => onChange(it.id)} className={`d-navitem ${view===it.id?'on':''}`}>
            <span style={{fontSize:'16px', width:'22px'}}>{it.ic}</span>
            <span>{it.label}</span>
            {it.primary && <span style={{marginLeft:'auto', width:'6px', height:'6px', background:'var(--mint-3)', borderRadius:'50%'}}/>}
          </div>
        ))}

        <div className="stroke dash soft" style={{margin:'16px 8px'}}/>
        <div className="label" style={{padding:'0 12px 6px'}}>快速存取</div>
        <div className="d-navitem"><span style={{fontSize:'14px', width:'22px'}}>⭐</span><span>草稿 (2)</span></div>
        <div className="d-navitem"><span style={{fontSize:'14px', width:'22px'}}>📌</span><span>釘選群組</span></div>
      </nav>

      <div style={{padding:'12px 16px', borderTop:'1.25px solid var(--line-soft)'}}>
        <div className="row">
          <div style={{width:'32px', height:'32px', borderRadius:'50%', background:'var(--mint-3)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-hand)', fontWeight:700}}>劉</div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:'12px', fontWeight:600}}>劉瑞弘</div>
            <div style={{fontSize:'10px', color:'var(--ink-3)', overflow:'hidden', textOverflow:'ellipsis'}}>liu@ncut.edu.tw</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

function DTopbar(){
  const [state, store] = window.useStore();
  const titles = {dashboard:'儀表板',scan:'新增掃描',contacts:'聯絡人',history:'寄件歷史',tools:'工具箱',settings:'設定'};
  return (
    <div className="d-topbar">
      <div>
        <div className="label">工作區</div>
        <h1 className="hand" style={{fontSize:'22px', fontWeight:700, lineHeight:1, marginTop:'2px'}}>{titles[state.dView]}</h1>
      </div>
      <div className="row" style={{marginLeft:'auto', gap:'8px'}}>
        <div className="card" style={{padding:'6px 10px', display:'flex', gap:'6px', alignItems:'center', minWidth:'260px'}}>
          <span style={{color:'var(--ink-3)'}}>🔍</span>
          <input className="input" placeholder="搜尋文件、聯絡人..." style={{border:'none', padding:0, background:'transparent'}}/>
          <span className="chip" style={{fontSize:'10px'}}>⌘K</span>
        </div>
        <button className="iconbtn">🔔</button>
        <button className="iconbtn">❓</button>
        <button className="pill primary" style={{fontSize:'12px'}} onClick={() => {store.startScan(); store.dSetView('scan');}}>＋ 新掃描</button>
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────
function DDashboard(){
  const [state, store] = window.useStore();
  const stats = [
    {label:'本週寄送', v:12, sub:'↑ 3 vs 上週', color:'var(--mint-4)'},
    {label:'本月總計', v:47, sub:'28 GB 處理', color:'var(--ink)'},
    {label:'聯絡人', v:state.contacts.length, sub:`${state.groups.length} 個群組`, color:'var(--ink-2)'},
    {label:'平均時間', v:'54s', sub:'每份文件', color:'var(--mint-4)'},
  ];

  return (
    <>
      <div className="d-grid-2" style={{marginBottom:'20px'}}>
        <div className="card ink" style={{padding:'24px', gridColumn:'1 / span 2'}}>
          <div className="row between">
            <div>
              <div className="label" style={{color:'rgba(255,255,255,0.5)'}}>快速開始</div>
              <div className="hand" style={{fontSize:'30px', fontWeight:700, marginTop:'6px', lineHeight:1.1}}>準備好寄送下一份文件了嗎？</div>
              <div style={{fontSize:'12px', opacity:0.7, marginTop:'6px'}}>從 12 個月前開始，已寄送 487 份公文 · 節省 32 小時</div>
              <div className="row" style={{gap:'8px', marginTop:'18px'}}>
                <button className="pill primary" onClick={() => {store.startScan(); store.dSetView('scan');}} style={{background:'var(--mint-3)', color:'#fff', borderColor:'var(--mint-3)'}}>📷 開始掃描</button>
                <button className="pill" style={{color:'#fff', borderColor:'rgba(255,255,255,0.3)', background:'transparent'}}>📁 上傳檔案</button>
              </div>
            </div>
            <div style={{fontSize:'90px', opacity:0.2, lineHeight:1}}>📬</div>
          </div>
        </div>

        {stats.map(s => (
          <div key={s.label} className="card" style={{padding:'16px'}}>
            <div className="label">{s.label}</div>
            <div className="hand" style={{fontSize:'34px', fontWeight:700, lineHeight:1, color:s.color, marginTop:'4px'}}>{s.v}</div>
            <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'4px'}}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="d-grid-split">
        <div>
          <div className="row between" style={{marginBottom:'10px'}}>
            <div className="hand" style={{fontSize:'20px', fontWeight:700}}>最近寄送</div>
            <span onClick={() => store.dSetView('history')} style={{fontSize:'11px', color:'var(--mint-3)', cursor:'pointer'}}>全部 ›</span>
          </div>
          <div className="col" style={{gap:'6px'}}>
            {state.history.map(h => (
              <div key={h.id} className="card" style={{padding:'12px 14px', cursor:'pointer'}}>
                <div className="row between" style={{marginBottom:'4px'}}>
                  <DocTypeBadge type={h.docType} confidence={h.confidence}/>
                  <span style={{fontSize:'10px', color:'var(--ink-3)'}}>{h.sentAt}</span>
                </div>
                <div style={{fontSize:'13px', fontWeight:500, marginTop:'4px'}}>{h.subject}</div>
                <div className="row between" style={{marginTop:'4px'}}>
                  <span style={{fontSize:'11px', color:'var(--ink-3)'}}>→ {h.recipient}</span>
                  <span style={{fontSize:'10px', fontFamily:'var(--font-mono)', color:'var(--ink-3)'}}>{h.size} · {h.pages}p</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="hand" style={{fontSize:'20px', fontWeight:700, marginBottom:'10px'}}>文件類型分佈</div>
          <div className="card" style={{padding:'16px'}}>
            {Object.entries(window.docTypes).slice(0,6).map(([k,t], i) => {
              const vals = [32,18,14,10,8,5];
              const max = 32;
              return (
                <div key={k} style={{marginBottom:'10px'}}>
                  <div className="row between" style={{marginBottom:'3px'}}>
                    <span style={{fontSize:'12px'}}>{t.icon} {t.label}</span>
                    <span style={{fontSize:'11px', color:'var(--ink-3)', fontFamily:'var(--font-mono)'}}>{vals[i]}</span>
                  </div>
                  <div style={{height:'5px', background:'var(--paper-2)', borderRadius:'3px', overflow:'hidden'}}>
                    <div style={{height:'100%', width:(vals[i]/max*100)+'%', background:t.color, borderRadius:'3px'}}/>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="hand" style={{fontSize:'20px', fontWeight:700, marginTop:'18px', marginBottom:'10px'}}>常用收件人</div>
          <div className="col" style={{gap:'4px'}}>
            {state.contacts.slice(0,3).map(c => (
              <ContactTile key={c.id} contact={c} onClick={() => {}} compact/>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

// ─── SCAN VIEW (desktop 3-column) ─────────────────────────
function DScan(){
  const [state, store] = window.useStore();
  const [phase, setPhase] = dUseState('capture'); // capture | edit | recipient | preview

  React.useEffect(() => {
    if(state.aiResult) setPhase('preview');
    else if(state.selectedContactIds.length) setPhase('recipient');
    else if(state.pages.length) setPhase('edit');
  }, []);

  return (
    <div style={{display:'grid', gridTemplateColumns:'300px 1fr 340px', gap:'16px', height:'100%'}}>
      {/* LEFT: pages */}
      <div className="card" style={{padding:'14px', overflow:'auto'}}>
        <div className="row between" style={{marginBottom:'10px'}}>
          <div className="label">頁面 ({state.pages.length})</div>
          <button className="chip on" onClick={() => {store.addPage(); setPhase('edit');}}>＋ 新增</button>
        </div>
        <div className="col" style={{gap:'8px'}}>
          {state.pages.length === 0 ? (
            <div className="card dash" style={{padding:'30px 14px', textAlign:'center', background:'var(--paper-2)', cursor:'pointer'}} onClick={() => {store.addPage(); setPhase('edit');}}>
              <div style={{fontSize:'38px', opacity:0.4}}>📷</div>
              <div className="hand" style={{fontSize:'17px', marginTop:'6px'}}>拖放圖片</div>
              <div style={{fontSize:'10.5px', color:'var(--ink-3)', marginTop:'3px'}}>或 <span style={{color:'var(--mint-3)', textDecoration:'underline'}}>瀏覽檔案</span></div>
            </div>
          ) : (
            state.pages.map((p, i) => (
              <PageThumb key={p.id} page={p} idx={i}
                active={p.id === state.currentPageId}
                onClick={() => store.setCurrentPage(p.id)}
                onRemove={state.pages.length > 1 ? () => store.removePage(p.id) : null}/>
            ))
          )}
          {state.pages.length > 0 && (
            <button className="card dash" style={{padding:'10px', textAlign:'center', background:'transparent', cursor:'pointer', fontSize:'12px', color:'var(--ink-3)'}} onClick={() => store.addPage()}>
              ＋ 加一頁
            </button>
          )}
        </div>
      </div>

      {/* CENTER: editor */}
      <div style={{display:'flex', flexDirection:'column', gap:'12px', minHeight:0}}>
        <div style={{background:'var(--paper-2)', borderRadius:'14px', padding:'24px', flex:1, display:'flex', alignItems:'center', justifyContent:'center', border:'1.25px solid var(--line-soft)', position:'relative', overflow:'hidden'}}>
          {state.pages.length === 0 ? (
            <div style={{textAlign:'center'}}>
              <div style={{fontSize:'64px', opacity:0.3}}>📄</div>
              <div className="hand" style={{fontSize:'22px', marginTop:'10px', color:'var(--ink-3)'}}>尚未匯入文件</div>
              <div style={{fontSize:'12px', color:'var(--ink-3)', marginTop:'4px'}}>從左側拖放或點擊「新增」</div>
            </div>
          ) : (
            <div style={{position:'relative'}}>
              <PaperDoc w="340px"/>
              <CropCorners/>
              <div style={{position:'absolute', top:'-30px', right:0, fontSize:'10px', fontFamily:'var(--font-mono)', color:'var(--ink-3)'}}>1240 × 1754</div>
            </div>
          )}
        </div>

        <div className="card" style={{padding:'12px 16px'}}>
          <div className="row">
            <div style={{display:'flex', gap:'6px'}}>
              <button className="iconbtn" title="左轉">↺</button>
              <button className="iconbtn" title="右轉">↻</button>
              <button className="iconbtn" title="縮放">🔍</button>
              <button className="iconbtn" title="還原">↩</button>
            </div>
            <div style={{flex:1, marginLeft:'16px'}}>
              <FilterStrip
                selected={state.pages.find(p => p.id === state.currentPageId)?.filter || 'auto'}
                onChange={(f) => store.setFilter(f)}/>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT: actions */}
      <div className="col" style={{gap:'12px', overflow:'auto'}}>
        <div className="card" style={{padding:'14px'}}>
          <div className="label" style={{marginBottom:'8px'}}>收件人 ({state.selectedContactIds.length})</div>
          {state.selectedContactIds.length === 0 ? (
            <button className="btn primary" style={{width:'100%'}} onClick={() => store.toggleContact('c1')}>
              ＋ 選擇收件人
            </button>
          ) : (
            <>
              <div className="col" style={{gap:'4px', marginBottom:'8px'}}>
                {state.selectedContactIds.slice(0,4).map(id => {
                  const c = state.contacts.find(x => x.id === id);
                  return c ? <ContactTile key={id} contact={c} selected onClick={() => store.toggleContact(id)} compact/> : null;
                })}
              </div>
              <button className="btn" style={{width:'100%'}}>＋ 加入更多</button>
            </>
          )}
          <div className="stroke dash soft" style={{margin:'10px 0'}}/>
          <div className="label" style={{marginBottom:'6px'}}>或選群組</div>
          <div className="row wrap" style={{gap:'4px'}}>
            {state.groups.map(g => (
              <span key={g.id} className="chip" style={{cursor:'pointer'}} onClick={() => {store.selectGroup(g.id); store.toast(`已選 ${g.memberIds.length} 人`);}}>
                📋 {g.name}
              </span>
            ))}
          </div>
        </div>

        {!state.aiResult ? (
          <div className="card mint" style={{padding:'14px'}}>
            <div className="row between" style={{marginBottom:'4px'}}>
              <span style={{fontSize:'11px', fontWeight:600, color:'var(--mint-4)'}}>🤖 AI 智慧辨識</span>
              <span className="chip mint">GEMINI</span>
            </div>
            <div style={{fontSize:'11px', color:'var(--ink-3)', marginBottom:'10px', lineHeight:1.5}}>
              自動分析文件類型、擷取關鍵資訊、產生郵件主旨與正文
            </div>
            <button className="btn primary" style={{width:'100%'}}
              disabled={!state.pages.length || !state.selectedContactIds.length}
              onClick={() => {store.runAI();}}>
              {state.aiLoading ? '⏳ 辨識中...' : '✨ 開始 AI 辨識'}
            </button>
            {!state.pages.length && <div style={{fontSize:'10px', color:'var(--ink-3)', marginTop:'6px', textAlign:'center'}}>需先上傳頁面</div>}
            {state.pages.length && !state.selectedContactIds.length && <div style={{fontSize:'10px', color:'var(--ink-3)', marginTop:'6px', textAlign:'center'}}>需先選收件人</div>}
          </div>
        ) : (
          <div className="card" style={{padding:'14px'}}>
            <DocTypeBadge type={state.aiResult.docType} confidence={state.aiResult.confidence}/>
            <div className="label" style={{marginTop:'10px'}}>主旨</div>
            <input className="input" defaultValue={state.aiResult.subject} style={{fontWeight:600, marginTop:'4px'}}/>
            <div className="label" style={{marginTop:'10px'}}>正文</div>
            <textarea className="input" defaultValue={state.aiResult.body} rows={6} style={{marginTop:'4px', fontSize:'12px', lineHeight:1.6, resize:'vertical'}}/>
            <div className="label" style={{marginTop:'10px'}}>附件</div>
            <div className="row" style={{fontSize:'11px', fontFamily:'var(--font-mono)', marginTop:'4px'}}>
              <span>📎 {state.aiResult.filename}</span>
            </div>
            <div className="stroke dash soft" style={{margin:'10px 0'}}/>
            <button className="btn primary" style={{width:'100%'}} onClick={() => {store.sendEmail(); store.toast('✓ 已寄送', 'ok'); setTimeout(() => { store.resetScan(); store.dSetView('history'); }, 800);}}>
              📤 寄送 Email
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── CONTACTS (desktop) ───────────────────────────────────
function DContacts(){
  const [state, store] = window.useStore();
  const [sel, setSel] = dUseState(state.contacts[0]?.id);
  const [q, setQ] = dUseState('');
  const filtered = state.contacts.filter(c => !q || c.name.includes(q) || c.email.toLowerCase().includes(q.toLowerCase()));
  const current = state.contacts.find(c => c.id === sel);

  return (
    <div style={{display:'grid', gridTemplateColumns:'320px 1fr', gap:'16px', height:'100%'}}>
      <div className="card" style={{padding:'12px', overflow:'auto'}}>
        <div className="row" style={{marginBottom:'10px'}}>
          <input className="input" placeholder="🔍 搜尋..." value={q} onChange={e => setQ(e.target.value)}/>
          <button className="pill primary" style={{fontSize:'12px', flexShrink:0, marginLeft:'6px'}}>＋</button>
        </div>
        <div className="label" style={{padding:'0 2px 4px'}}>群組</div>
        <div className="row wrap" style={{gap:'4px', marginBottom:'10px'}}>
          {state.groups.map(g => <span key={g.id} className="chip">📋 {g.name} ({g.memberIds.length})</span>)}
        </div>
        <div className="stroke dash soft" style={{margin:'6px 0 10px'}}/>
        <div className="label" style={{padding:'0 2px 6px'}}>聯絡人 ({filtered.length})</div>
        <div className="col" style={{gap:'4px'}}>
          {filtered.map(c => (
            <ContactTile key={c.id} contact={c} selected={c.id === sel} onClick={() => setSel(c.id)} compact/>
          ))}
        </div>
      </div>

      <div style={{overflow:'auto'}}>
        {current ? (
          <>
            <div className="card" style={{padding:'22px', marginBottom:'14px'}}>
              <div className="row">
                <div style={{width:'64px', height:'64px', borderRadius:'50%', background:'var(--mint-wash)', color:'var(--mint-4)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-hand)', fontWeight:700, fontSize:'24px', border:'1.5px solid var(--mint-3)'}}>{current.name.slice(-2)}</div>
                <div style={{flex:1}}>
                  <div className="row">
                    <h2 className="hand" style={{fontSize:'24px', fontWeight:700}}>{current.name}</h2>
                    {current.fav && <span style={{color:'#c89b3b', fontSize:'18px'}}>★</span>}
                  </div>
                  <div style={{fontSize:'12px', color:'var(--ink-3)', marginTop:'2px'}}>{current.title} · {current.dept}</div>
                  <div style={{fontSize:'12px', color:'var(--mint-4)', fontFamily:'var(--font-mono)', marginTop:'2px'}}>{current.email}</div>
                </div>
                <div style={{display:'flex', gap:'6px'}}>
                  <button className="pill">✏ 編輯</button>
                  <button className="pill">📤 寄送</button>
                </div>
              </div>
              <div className="stroke dash soft" style={{margin:'14px 0'}}/>
              <div className="row" style={{gap:'20px'}}>
                <div><div className="label">寄送次數</div><div className="hand" style={{fontSize:'22px', fontWeight:700}}>{current.freq}</div></div>
                <div><div className="label">上次寄送</div><div style={{fontSize:'13px', fontWeight:500, marginTop:'2px'}}>2026/04/09</div></div>
                <div><div className="label">所屬群組</div><div style={{fontSize:'12px', marginTop:'2px'}}>{state.groups.filter(g => g.memberIds.includes(current.id)).map(g => g.name).join(', ') || '—'}</div></div>
              </div>
            </div>

            <div className="card" style={{padding:'18px'}}>
              <div className="hand" style={{fontSize:'18px', fontWeight:700, marginBottom:'10px'}}>最近寄件紀錄</div>
              <div className="col" style={{gap:'6px'}}>
                {state.history.slice(0,3).map(h => (
                  <div key={h.id} className="card" style={{padding:'10px 12px', boxShadow:'none'}}>
                    <div className="row between">
                      <DocTypeBadge type={h.docType}/>
                      <span style={{fontSize:'10px', color:'var(--ink-3)'}}>{h.sentAt}</span>
                    </div>
                    <div style={{fontSize:'12.5px', fontWeight:500, marginTop:'4px'}}>{h.subject}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : <div style={{color:'var(--ink-3)', padding:'40px', textAlign:'center'}}>選擇聯絡人檢視詳情</div>}
      </div>
    </div>
  );
}

// ─── HISTORY (desktop table) ───────────────────────────────
function DHistory(){
  const [state] = window.useStore();
  return (
    <div className="card" style={{padding:'16px 18px'}}>
      <div className="row between" style={{marginBottom:'14px'}}>
        <div>
          <div className="label">已寄送</div>
          <div className="hand" style={{fontSize:'22px', fontWeight:700}}>{state.history.length} 筆紀錄</div>
        </div>
        <div className="row" style={{gap:'6px'}}>
          <input className="input" placeholder="🔍 搜尋..." style={{width:'240px'}}/>
          <button className="pill on">全部</button>
          {Object.entries(window.docTypes).slice(0,3).map(([k,t]) => <button key={k} className="pill">{t.icon} {t.label}</button>)}
          <button className="pill">📤 匯出</button>
        </div>
      </div>

      <table className="d-table">
        <thead>
          <tr>
            <th>主旨</th><th>類型</th><th>收件人</th><th>寄送時間</th><th>大小</th><th>狀態</th><th></th>
          </tr>
        </thead>
        <tbody>
          {state.history.map(h => (
            <tr key={h.id}>
              <td style={{fontWeight:500}}>{h.subject}</td>
              <td><DocTypeBadge type={h.docType} confidence={h.confidence}/></td>
              <td><span style={{fontSize:'12px', color:'var(--ink-2)'}}>{h.recipient}</span></td>
              <td><span style={{fontSize:'11px', color:'var(--ink-3)', fontFamily:'var(--font-mono)'}}>{h.sentAt}</span></td>
              <td><span style={{fontSize:'11px', fontFamily:'var(--font-mono)'}}>{h.size}</span></td>
              <td><span className="chip mint">✓ 已送達</span></td>
              <td><button className="iconbtn">⋯</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── TOOLS (desktop) ──────────────────────────────────────
function DTools(){
  const tools = [
    {id:'image', ic:'🖼️', t:'圖片工具', desc:'縮放、轉檔、壓縮、浮水印', color:'var(--mint-wash)'},
    {id:'pdf', ic:'📕', t:'PDF 工具', desc:'合併、浮水印、加密保護', color:'#fef2d8'},
    {id:'convert', ic:'🔄', t:'文件轉檔', desc:'Word ↔ PDF ↔ Markdown', color:'#e8eef5'},
    {id:'gif', ic:'🎞️', t:'GIF 製作', desc:'圖片序列產生動畫', color:'#f5e4dc'},
    {id:'video', ic:'🎬', t:'影片工具', desc:'合併、轉 GIF、壓縮', color:'#e8e1ef'},
    {id:'rename', ic:'✏️', t:'批次改名', desc:'前後綴、取代、編號', color:'#e2efe7'},
  ];

  return (
    <>
      <div className="hand" style={{fontSize:'26px', fontWeight:700, marginBottom:'14px'}}>所有工具</div>
      <div className="d-grid-3">
        {tools.map(t => (
          <div key={t.id} className="card" style={{padding:'20px', cursor:'pointer'}}>
            <div style={{width:'50px', height:'50px', borderRadius:'12px', background:t.color, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'26px', marginBottom:'10px'}}>{t.ic}</div>
            <div className="hand" style={{fontSize:'20px', fontWeight:700, marginBottom:'4px'}}>{t.t}</div>
            <div style={{fontSize:'12px', color:'var(--ink-3)', marginBottom:'10px', lineHeight:1.5}}>{t.desc}</div>
            <button className="pill">開啟 →</button>
          </div>
        ))}
      </div>

      <div className="card fill" style={{padding:'22px', marginTop:'20px'}}>
        <div className="hand" style={{fontSize:'20px', fontWeight:700, marginBottom:'14px'}}>批次處理佇列</div>
        <div className="card dash" style={{padding:'40px 20px', textAlign:'center', background:'var(--paper)'}}>
          <div style={{fontSize:'44px', opacity:0.3}}>📁</div>
          <div className="hand" style={{fontSize:'18px', marginTop:'8px', color:'var(--ink-3)'}}>拖放檔案到這裡</div>
          <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'4px'}}>或 <span style={{color:'var(--mint-3)', textDecoration:'underline'}}>瀏覽本機</span></div>
        </div>
      </div>
    </>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────
function DSettings(){
  const sections = [
    {title:'寄件人資料', fields:[['姓名','劉瑞弘'],['職稱','副教授'],['單位','智慧自動化工程系'],['組織','國立勤益科技大學']]},
    {title:'SMTP 設定', fields:[['SMTP Host','smtp.gmail.com'],['Port','587'],['帳號','liu@ncut.edu.tw'],['密碼','••••••••••']]},
  ];
  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px'}}>
      {sections.map(s => (
        <div key={s.title} className="card" style={{padding:'20px'}}>
          <div className="hand" style={{fontSize:'20px', fontWeight:700, marginBottom:'14px'}}>{s.title}</div>
          {s.fields.map(([k,v]) => (
            <div key={k} style={{marginBottom:'10px'}}>
              <div className="field-label">{k}</div>
              <input className="input" defaultValue={v}/>
            </div>
          ))}
          <button className="btn primary" style={{marginTop:'6px'}}>💾 儲存</button>
        </div>
      ))}
      <div className="card" style={{padding:'20px', gridColumn:'1/-1'}}>
        <div className="hand" style={{fontSize:'20px', fontWeight:700, marginBottom:'14px'}}>AI / Gemini 設定</div>
        <div className="row" style={{gap:'12px'}}>
          <div style={{flex:1}}>
            <div className="field-label">API Key</div>
            <input className="input" type="password" defaultValue="AIzaSy••••••••••••••••"/>
          </div>
          <div style={{flex:1}}>
            <div className="field-label">模型</div>
            <input className="input" defaultValue="gemini-2.5-flash"/>
          </div>
        </div>
        <div className="row" style={{marginTop:'14px', gap:'8px'}}>
          <span className="chip mint">✓ 已連線</span>
          <button className="pill">測試連線</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DesktopShell });
