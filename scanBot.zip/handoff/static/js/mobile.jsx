/* Mobile screens — all routes */
const { useState: mUseState } = React;

function MobileShell(){
  const [state, store] = window.useStore();
  const screen = state.mStack[state.mStack.length - 1] || state.mTab;

  const renderScreen = () => {
    switch(screen){
      case 'home': return <MHome/>;
      case 'scan': return <MScan/>;
      case 'tools': return <MTools/>;
      case 'history': return <MHistory/>;
      case 'more': return <MMore/>;
      case 'scan-capture': return <MScanCapture/>;
      case 'scan-crop': return <MScanCrop/>;
      case 'scan-contacts': return <MScanContacts/>;
      case 'scan-ai': return <MScanAI/>;
      case 'scan-preview': return <MScanPreview/>;
      case 'scan-success': return <MScanSuccess/>;
      case 'contacts': return <MContacts/>;
      case 'tool-image': return <MToolImage/>;
      case 'tool-pdf': return <MToolPdf/>;
      case 'tool-convert': return <MToolConvert/>;
      case 'tool-gif': return <MToolGif/>;
      case 'tool-video': return <MToolVideo/>;
      case 'tool-rename': return <MToolRename/>;
      case 'settings': return <MSettings/>;
      default: return <MHome/>;
    }
  };

  const inScan = screen.startsWith('scan-') || screen === 'scan';
  const hideTabBar = ['scan-capture','scan-crop'].includes(screen);

  return (
    <div className="phone">
      <div className="phone-inner">
        <div className="status-bar">
          <span>9:41</span>
          <span>●●● ▪ 100%</span>
        </div>
        <div className="m-screen">
          {renderScreen()}
        </div>
        {!hideTabBar && <MTabBar active={state.mTab} onChange={(t) => store.mSetTab(t)}/>}
        <Toasts toasts={state.toasts}/>
      </div>
    </div>
  );
}

function MTabBar({ active, onChange }){
  const tabs = [
    { id:'home', ic:'⌂', label:'首頁' },
    { id:'tools', ic:'🛠', label:'工具' },
    { id:'scan', ic:'📷', label:'掃描', accent:true },
    { id:'history', ic:'🕒', label:'歷史' },
    { id:'more', ic:'☰', label:'更多' },
  ];
  return (
    <div className="m-tabbar">
      {tabs.map(t => (
        <div key={t.id} className={`m-tab ${active === t.id ? 'on' : ''} ${t.accent ? 'accent':''}`} onClick={() => onChange(t.id)}>
          <div className="ic">{t.ic}</div>
          <span>{t.label}</span>
        </div>
      ))}
    </div>
  );
}

function MHeader({ title, back, actions, subt }){
  const [, store] = window.useStore();
  return (
    <div className="m-header">
      <div style={{display:'flex', alignItems:'center', gap:'8px'}}>
        {back && <span className="m-back" onClick={() => store.mBack()}>‹</span>}
        <div>
          <h2>{title}</h2>
          {subt && <div className="subt">{subt}</div>}
        </div>
      </div>
      <div className="acts">{actions}</div>
    </div>
  );
}

// ─── HOME ──────────────────────────────────────────────────
function MHome(){
  const [state, store] = window.useStore();
  const recent = state.history.slice(0, 3);
  const tools = [
    {id:'scan', ic:'📷', label:'掃描郵寄', primary:true, go:() => store.mSetTab('scan')},
    {id:'image', ic:'🖼️', label:'圖片工具', go:() => store.mGoto('tool-image')},
    {id:'pdf', ic:'📕', label:'PDF', go:() => store.mGoto('tool-pdf')},
    {id:'convert', ic:'🔄', label:'轉檔', go:() => store.mGoto('tool-convert')},
    {id:'gif', ic:'🎞️', label:'GIF', go:() => store.mGoto('tool-gif')},
    {id:'video', ic:'🎬', label:'影片', go:() => store.mGoto('tool-video')},
    {id:'rename', ic:'✏️', label:'改名', go:() => store.mGoto('tool-rename')},
    {id:'contacts', ic:'👥', label:'聯絡人', go:() => store.mGoto('contacts')},
  ];

  return (
    <>
      <div className="m-header">
        <div>
          <h2>ScanMail<span style={{color:'var(--mint-3)'}}>+</span></h2>
          <div className="subt">早安，劉老師</div>
        </div>
        <div className="acts">
          <button className="iconbtn">🔔</button>
          <button className="iconbtn">👤</button>
        </div>
      </div>
      <div className="m-body">
        <div className="card mint" style={{marginBottom:'14px'}}>
          <div className="row between">
            <div>
              <div className="mini" style={{color:'var(--mint-4)'}}>本週進度</div>
              <div className="hand" style={{fontSize:'28px', lineHeight:1, fontWeight:700, color:'var(--mint-4)'}}>12 份</div>
              <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'2px'}}>已寄送 · 比上週 ↑ 3</div>
            </div>
            <div style={{fontSize:'42px', opacity:0.4}}>📬</div>
          </div>
        </div>

        <div className="label" style={{marginBottom:'8px'}}>所有工具</div>
        <div className="grid-3" style={{marginBottom:'16px'}}>
          {tools.map(t => (
            <div key={t.id} onClick={t.go} style={{
              padding:'14px 6px', borderRadius:'12px', textAlign:'center',
              background: t.primary ? 'var(--ink)' : 'var(--paper)',
              color: t.primary ? 'var(--paper)' : 'var(--ink)',
              border: t.primary ? '1.25px solid var(--ink)' : '1.25px solid var(--line-soft)',
              cursor:'pointer',
              position:'relative',
            }}>
              <div style={{fontSize:'26px', marginBottom:'4px'}}>{t.ic}</div>
              <div style={{fontSize:'11px', fontWeight:500}}>{t.label}</div>
              {t.primary && <div style={{position:'absolute', top:'6px', right:'6px', width:'6px', height:'6px', background:'var(--mint)', borderRadius:'50%'}}/>}
            </div>
          ))}
        </div>

        <div className="row between" style={{marginBottom:'8px'}}>
          <span className="label">最近寄送</span>
          <span onClick={() => store.mSetTab('history')} style={{fontSize:'11px', color:'var(--mint-3)', cursor:'pointer'}}>全部 ›</span>
        </div>
        <div className="col" style={{gap:'6px'}}>
          {recent.map(h => (
            <div key={h.id} className="card" style={{padding:'10px 12px'}}>
              <div className="row">
                <DocTypeBadge type={h.docType}/>
                <span style={{fontSize:'10px', color:'var(--ink-3)', marginLeft:'auto'}}>{h.sentAt}</span>
              </div>
              <div style={{fontSize:'12.5px', marginTop:'6px', fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{h.subject}</div>
              <div style={{fontSize:'11px', color:'var(--ink-3)'}}>→ {h.recipient}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── SCAN ENTRY ────────────────────────────────────────────
function MScan(){
  const [, store] = window.useStore();
  return (
    <>
      <MHeader title="掃描郵寄" subt="拍照 → AI → Email"/>
      <div className="m-body">
        <div className="card ink" style={{padding:'24px 20px', textAlign:'center', marginBottom:'14px'}}>
          <div style={{fontSize:'52px', lineHeight:1, marginBottom:'10px'}}>📷</div>
          <div className="hand" style={{fontSize:'30px', fontWeight:700, lineHeight:1}}>開始新掃描</div>
          <div style={{fontSize:'12px', opacity:0.7, margin:'6px 0 16px'}}>一分鐘搞定 · AI 自動撰寫</div>
          <button className="pill primary" style={{background:'var(--paper)', color:'var(--ink)', borderColor:'var(--paper)', fontSize:'14px', padding:'10px 22px'}}
            onClick={() => {store.startScan(); store.mGoto('scan-capture');}}>
            📸 拍照掃描 →
          </button>
        </div>

        <div className="grid-2">
          <div className="card" style={{padding:'14px', textAlign:'center'}} onClick={() => {store.startScan(); store.addPage(); store.mGoto('scan-crop');}}>
            <div style={{fontSize:'26px'}}>📁</div>
            <div style={{fontSize:'12.5px', fontWeight:500, marginTop:'4px'}}>上傳檔案</div>
            <div style={{fontSize:'10px', color:'var(--ink-3)'}}>JPG / PNG / PDF</div>
          </div>
          <div className="card" style={{padding:'14px', textAlign:'center'}}>
            <div style={{fontSize:'26px'}}>🗂</div>
            <div style={{fontSize:'12.5px', fontWeight:500, marginTop:'4px'}}>草稿 (2)</div>
            <div style={{fontSize:'10px', color:'var(--ink-3)'}}>繼續編輯</div>
          </div>
        </div>

        <div className="stroke soft dash" style={{margin:'18px 0'}}/>

        <div className="label" style={{marginBottom:'8px'}}>最近文件類型</div>
        <div className="row wrap" style={{gap:'6px'}}>
          {Object.entries(window.docTypes).slice(0,6).map(([k,t]) => (
            <span key={k} className="chip">{t.icon} {t.label}</span>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── SCAN: CAPTURE (camera) ────────────────────────────────
function MScanCapture(){
  const [state, store] = window.useStore();
  const [detected, setDetected] = mUseState(false);

  React.useEffect(() => {
    const t = setTimeout(() => setDetected(true), 800);
    return () => clearTimeout(t);
  }, []);

  const shoot = () => {
    store.addPage();
    store.toast('📸 已擷取', 'ok');
    store.mGoto('scan-crop');
  };

  return (
    <>
      <div className="m-header" style={{background:'#141c18', borderColor:'rgba(255,255,255,0.08)'}}>
        <div style={{display:'flex', alignItems:'center', gap:'8px'}}>
          <span className="m-back" style={{color:'#fff'}} onClick={() => store.mBack()}>‹</span>
          <h2 style={{color:'#fff'}}>掃描</h2>
        </div>
        <div className="acts">
          <button className="iconbtn" style={{background:'rgba(255,255,255,0.1)', color:'#fff', borderColor:'rgba(255,255,255,0.2)'}}>⚡</button>
          <button className="iconbtn" style={{background:'rgba(255,255,255,0.1)', color:'#fff', borderColor:'rgba(255,255,255,0.2)'}}>⚙</button>
        </div>
      </div>
      <div style={{flex:1, position:'relative', background:'#141c18', overflow:'hidden'}}>
        <CameraView detected={detected}/>
        <div style={{position:'absolute', top:'14px', left:'50%', transform:'translateX(-50%)', zIndex:2}}>
          <span className="pill" style={{background:'rgba(0,0,0,0.6)', color:'#fff', borderColor:'rgba(255,255,255,0.3)', fontSize:'11px'}}>
            📄 第 {state.pages.length + 1} 頁 · {detected ? '✓ 偵測中' : '搜尋文件...'}
          </span>
        </div>
        {detected && (
          <div style={{position:'absolute', top:'50%', left:'50%', transform:'translate(-50%, 40px)', zIndex:3}}>
            <span className="pill" style={{background:'var(--mint-3)', color:'#fff', border:'none', fontSize:'12px', fontFamily:'var(--font-hand)'}}>
              ✓ 偵測到文件邊界
            </span>
          </div>
        )}

        <div style={{position:'absolute', bottom:'110px', left:0, right:0, display:'flex', justifyContent:'center', padding:'0 16px'}}>
          <div style={{display:'flex', gap:'8px'}}>
            {['自動','掃描','文件','黑白'].map((l,i) => (
              <span key={l} className="chip" style={{
                background: i===0 ? '#fff' : 'rgba(0,0,0,0.5)',
                color: i===0 ? '#000' : '#fff',
                border: i===0 ? 'none' : '1px solid rgba(255,255,255,0.3)',
              }}>{l}</span>
            ))}
          </div>
        </div>

        <div style={{position:'absolute', bottom:'20px', left:0, right:0, display:'flex', alignItems:'center', justifyContent:'space-around', padding:'0 28px'}}>
          <button style={{width:'46px', height:'46px', borderRadius:'10px', background:'rgba(255,255,255,0.1)', color:'#fff', border:'1.25px solid rgba(255,255,255,0.3)', fontSize:'16px'}}>📁</button>
          <button onClick={shoot} style={{width:'72px', height:'72px', borderRadius:'50%', background:'rgba(255,255,255,0.2)', border:'3px solid #fff', padding:0, display:'flex', alignItems:'center', justifyContent:'center'}}>
            <div style={{width:'54px', height:'54px', background:'#fff', borderRadius:'50%'}}/>
          </button>
          <button style={{width:'46px', height:'46px', borderRadius:'10px', background:state.pages.length ? 'var(--mint-3)' : 'rgba(255,255,255,0.1)', color:'#fff', border:state.pages.length ? 'none':'1.25px solid rgba(255,255,255,0.3)', fontSize:'11px', flexDirection:'column', display:'flex', alignItems:'center', justifyContent:'center'}}
            onClick={() => state.pages.length && store.mGoto('scan-crop')}>
            <span style={{fontSize:'18px'}}>📄</span>
            <span style={{fontSize:'10px'}}>{state.pages.length}</span>
          </button>
        </div>
      </div>
    </>
  );
}

// ─── SCAN: CROP + FILTER ───────────────────────────────────
function MScanCrop(){
  const [state, store] = window.useStore();
  const current = state.pages.find(p => p.id === state.currentPageId);
  const [phase, setPhase] = mUseState('crop'); // crop | filter

  React.useEffect(() => {
    if(!current) store.addPage();
  }, []);

  if(!current) return null;

  return (
    <>
      <div className="m-header">
        <div style={{display:'flex', alignItems:'center', gap:'8px'}}>
          <span className="m-back" onClick={() => store.mBack()}>‹</span>
          <div>
            <h2>{phase === 'crop' ? '裁切文件' : '選擇濾鏡'}</h2>
            <div className="subt">第 {state.pages.length} 頁 · {state.pages.length > 1 ? `共 ${state.pages.length} 頁` : '新文件'}</div>
          </div>
        </div>
        <div className="acts">
          <button className="pill primary" style={{fontSize:'12px', padding:'6px 14px'}} onClick={() => {
            if(phase === 'crop'){ setPhase('filter'); }
            else { store.mGoto('scan-contacts'); }
          }}>{phase === 'crop' ? '套用' : '下一步'} →</button>
        </div>
      </div>
      <div style={{flex:1, display:'flex', flexDirection:'column', minHeight:0}}>
        <div style={{flex:1, background:'var(--paper-2)', padding:'16px', display:'flex', alignItems:'center', justifyContent:'center', position:'relative'}}>
          <div style={{position:'relative'}}>
            <PaperDoc w="220px"/>
            {phase === 'crop' && <CropCorners/>}
          </div>
        </div>

        <div style={{background:'var(--paper)', borderTop:'1.25px solid var(--line-soft)', borderRadius:'16px 16px 0 0', padding:'12px 16px 16px', boxShadow:'0 -4px 12px rgba(0,0,0,0.04)'}}>
          <div style={{width:'36px', height:'4px', background:'var(--line-soft)', borderRadius:'2px', margin:'0 auto 12px'}}/>

          {phase === 'crop' ? (
            <>
              <div style={{display:'flex', justifyContent:'space-around', marginBottom:'12px'}}>
                {[{ic:'↺', l:'左轉'},{ic:'↻', l:'右轉'},{ic:'🔍', l:'自動', active:true},{ic:'↩', l:'重設'}].map((a,i) => (
                  <button key={i} onClick={() => store.toast(`${a.l}完成`,'ok')} style={{textAlign:'center', fontSize:'10px', color:a.active?'var(--mint-3)':'var(--ink-2)'}}>
                    <div style={{fontSize:'22px', marginBottom:'2px'}}>{a.ic}</div>{a.l}
                  </button>
                ))}
              </div>
              {state.pages.length > 0 && (
                <>
                  <div className="stroke dash soft"/>
                  <div className="label" style={{marginTop:'10px', marginBottom:'6px'}}>已掃描頁面</div>
                  <div className="row" style={{gap:'6px', overflowX:'auto', paddingBottom:'4px'}}>
                    {state.pages.map((p, i) => (
                      <div key={p.id} style={{flex:'0 0 58px'}}>
                        <PageThumb page={p} active={p.id === state.currentPageId} idx={i} onClick={() => store.setCurrentPage(p.id)}/>
                      </div>
                    ))}
                    <div onClick={() => {store.mBack();}} style={{flex:'0 0 58px', aspectRatio:'0.72', border:'1.5px dashed var(--line-soft)', borderRadius:'6px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'22px', color:'var(--ink-3)', cursor:'pointer'}}>＋</div>
                  </div>
                </>
              )}
            </>
          ) : (
            <>
              <div className="label" style={{marginBottom:'6px'}}>濾鏡</div>
              <FilterStrip selected={current.filter} onChange={(f) => store.setFilter(f)}/>
              <div className="stroke dash soft" style={{margin:'10px 0'}}/>
              <div className="row">
                <button className="pill" onClick={() => store.mGoto('scan-capture')} style={{fontSize:'12px'}}>＋ 加一頁</button>
                <button className="pill" onClick={() => store.applyFilterToAll(current.filter)} style={{marginLeft:'auto', fontSize:'12px'}}>套用到全部</button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

// ─── SCAN: CONTACTS ────────────────────────────────────────
function MScanContacts(){
  const [state, store] = window.useStore();
  const [tab, setTab] = mUseState('all');
  const [q, setQ] = mUseState('');

  const filtered = state.contacts.filter(c =>
    (tab === 'fav' ? c.fav : true) &&
    (!q || c.name.includes(q) || c.email.includes(q))
  ).sort((a,b) => b.freq - a.freq);

  return (
    <>
      <MHeader title="選擇收件人" back subt={`${state.selectedContactIds.length} 人已選`}
        actions={
          <button className="pill primary" style={{fontSize:'12px', padding:'6px 14px'}}
            disabled={!state.selectedContactIds.length}
            onClick={() => {store.mGoto('scan-ai'); store.runAI();}}>
            AI 辨識 →
          </button>
        }/>
      <div className="m-body">
        <div className="card" style={{padding:'8px 12px', marginBottom:'12px', display:'flex', alignItems:'center', gap:'8px'}}>
          <span>🔍</span>
          <input className="input" placeholder="搜尋姓名、email..." value={q} onChange={e => setQ(e.target.value)}
            style={{border:'none', padding:0, background:'transparent'}}/>
        </div>

        <div className="row" style={{gap:'6px', marginBottom:'12px', overflowX:'auto'}}>
          <button className={`chip ${tab==='all'?'on':''}`} onClick={() => setTab('all')}>全部 ({state.contacts.length})</button>
          <button className={`chip ${tab==='fav'?'on':''}`} onClick={() => setTab('fav')}>★ 常用</button>
          <button className={`chip ${tab==='groups'?'on':''}`} onClick={() => setTab('groups')}>群組</button>
        </div>

        {tab === 'groups' ? (
          <div className="col">
            {state.groups.map(g => (
              <div key={g.id} className="card" style={{padding:'12px'}} onClick={() => {store.selectGroup(g.id); store.toast(`已選 ${g.memberIds.length} 人`, 'ok');}}>
                <div className="row between">
                  <div>
                    <div style={{fontWeight:600, fontSize:'14px'}}>📋 {g.name}</div>
                    <div style={{fontSize:'11px', color:'var(--ink-3)'}}>{g.memberIds.length} 位成員</div>
                  </div>
                  <span className="pill primary" style={{fontSize:'11px'}}>一鍵全選</span>
                </div>
                <div className="row wrap" style={{gap:'4px', marginTop:'8px'}}>
                  {g.memberIds.slice(0,5).map(id => {
                    const c = state.contacts.find(x => x.id === id);
                    return c ? <span key={id} className="chip" style={{fontSize:'10px'}}>{c.name}</span> : null;
                  })}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="col" style={{gap:'6px'}}>
            {filtered.map(c => (
              <ContactTile key={c.id} contact={c} selected={state.selectedContactIds.includes(c.id)}
                onClick={() => store.toggleContact(c.id)}
                onFav={() => store.toggleFav(c.id)}/>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

// ─── SCAN: AI LOADING ──────────────────────────────────────
function MScanAI(){
  const [state, store] = window.useStore();

  React.useEffect(() => {
    if(state.aiResult && !state.aiLoading){
      const t = setTimeout(() => store.mGoto('scan-preview'), 400);
      return () => clearTimeout(t);
    }
  }, [state.aiResult, state.aiLoading]);

  return (
    <>
      <MHeader title="AI 辨識中" back/>
      <div className="m-body" style={{display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center'}}>
        <div style={{position:'relative', width:'120px', height:'120px', marginBottom:'20px'}}>
          <div style={{position:'absolute', inset:0, borderRadius:'50%', border:'4px solid var(--mint-wash)', borderTopColor:'var(--mint-3)', animation:'spin 1.2s linear infinite'}}/>
          <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'42px'}}>🤖</div>
        </div>
        <div className="hand" style={{fontSize:'24px', fontWeight:700, marginBottom:'4px'}}>Gemini 正在閱讀...</div>
        <div style={{fontSize:'12px', color:'var(--ink-3)', textAlign:'center', maxWidth:'260px'}}>辨識文件類型 · 擷取關鍵資訊 · 產生主旨與正文</div>
        <div className="col" style={{marginTop:'24px', width:'100%', gap:'6px'}}>
          {['分析文件類型','擷取關鍵文字','撰寫郵件主旨','產生檔案名稱'].map((t,i) => (
            <div key={i} className="row" style={{fontSize:'12px'}}>
              <span style={{width:'16px', height:'16px', borderRadius:'50%', background: i < 2 ? 'var(--mint-3)' : 'var(--paper-2)', color:'#fff', fontSize:'10px', display:'inline-flex', alignItems:'center', justifyContent:'center'}}>{i < 2 ? '✓' : i+1}</span>
              <span style={{color: i < 2 ? 'var(--mint-4)' : 'var(--ink-3)'}}>{t}</span>
            </div>
          ))}
        </div>
        <style>{`@keyframes spin{to{transform:rotate(360deg);}}`}</style>
      </div>
    </>
  );
}

// ─── SCAN: PREVIEW ─────────────────────────────────────────
function MScanPreview(){
  const [state, store] = window.useStore();
  const [editing, setEditing] = mUseState(false);
  const r = state.aiResult;
  if(!r) return null;

  const contacts = state.selectedContactIds.map(id => state.contacts.find(c => c.id === id)).filter(Boolean);

  return (
    <>
      <MHeader title="預覽確認" back subt="檢查無誤後寄出"
        actions={
          <button className="pill primary" style={{fontSize:'12px', padding:'6px 14px'}} onClick={() => {store.sendEmail(); store.mGoto('scan-success');}}>
            寄出 ✓
          </button>
        }/>
      <div className="m-body">
        <div className="card" style={{padding:'14px', marginBottom:'12px'}}>
          <div className="row between" style={{marginBottom:'8px'}}>
            <DocTypeBadge type={r.docType} confidence={r.confidence}/>
            <button onClick={() => setEditing(!editing)} className="chip">{editing?'完成':'編輯'}</button>
          </div>
          <div style={{fontSize:'10px', color:'var(--ink-3)', marginBottom:'2px'}}>主旨</div>
          {editing ? (
            <input className="input" defaultValue={r.subject} style={{fontSize:'14px', fontWeight:600, marginBottom:'10px'}}/>
          ) : (
            <div style={{fontSize:'14px', fontWeight:600, marginBottom:'10px', lineHeight:1.4}}>{r.subject}</div>
          )}
          <div className="stroke dash soft" style={{margin:'10px 0'}}/>
          <div style={{fontSize:'10px', color:'var(--ink-3)', marginBottom:'4px'}}>正文</div>
          {editing ? (
            <textarea className="input" defaultValue={r.body} rows={8} style={{fontSize:'12.5px', lineHeight:1.6, resize:'vertical', fontFamily:'var(--font-body)'}}/>
          ) : (
            <div style={{fontSize:'12.5px', lineHeight:1.7, whiteSpace:'pre-line', color:'var(--ink-2)'}}>{r.body}</div>
          )}
        </div>

        <div className="card fill" style={{padding:'12px', marginBottom:'12px'}}>
          <div className="label" style={{marginBottom:'6px'}}>收件人 ({contacts.length})</div>
          <div className="row wrap" style={{gap:'4px'}}>
            {contacts.map(c => <span key={c.id} className="chip mint">{c.name}</span>)}
          </div>
        </div>

        <div className="card" style={{padding:'10px 14px'}}>
          <div className="row between">
            <div>
              <div className="label">附件檔名</div>
              <div style={{fontSize:'12px', fontFamily:'var(--font-mono)', marginTop:'2px'}}>{r.filename}</div>
            </div>
            <div style={{fontSize:'24px'}}>📎</div>
          </div>
          <div className="stroke dash soft" style={{margin:'8px 0'}}/>
          <div className="row between" style={{fontSize:'11px', color:'var(--ink-3)'}}>
            <span>{state.pages.length} 頁 · PDF</span>
            <span>~420 KB</span>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── SCAN: SUCCESS ─────────────────────────────────────────
function MScanSuccess(){
  const [state, store] = window.useStore();
  const contacts = state.selectedContactIds.map(id => state.contacts.find(c => c.id === id)).filter(Boolean);

  return (
    <>
      <MHeader title="完成" actions={
        <button className="pill" style={{fontSize:'12px'}} onClick={() => {store.resetScan(); store.mSetTab('home');}}>✕</button>
      }/>
      <div className="m-body" style={{textAlign:'center'}}>
        <div style={{padding:'30px 0 10px'}}>
          <div className="check-anim">✓</div>
        </div>
        <div className="hand" style={{fontSize:'32px', fontWeight:700}}>寄送成功！</div>
        <div style={{fontSize:'13px', color:'var(--ink-3)', marginBottom:'20px'}}>已送達 {contacts.length} 位收件人</div>

        <div className="card fill" style={{padding:'12px', textAlign:'left', marginBottom:'14px'}}>
          <div style={{fontSize:'12px', color:'var(--ink-3)'}}>主旨</div>
          <div style={{fontSize:'13px', fontWeight:500, marginBottom:'6px'}}>{state.aiResult?.subject}</div>
          <div className="stroke dash soft" style={{margin:'6px 0'}}/>
          <div style={{fontSize:'12px', color:'var(--ink-3)'}}>收件人</div>
          <div style={{fontSize:'12.5px'}}>{contacts.map(c => c.name).join(', ')}</div>
        </div>

        <div className="label" style={{marginBottom:'8px'}}>接著想做什麼？</div>
        <div className="grid-2" style={{marginBottom:'10px'}}>
          <button className="card" style={{padding:'14px', textAlign:'center', cursor:'pointer'}} onClick={() => {store.resetScan(); store.mSetTab('scan');}}>
            <div style={{fontSize:'26px'}}>📷</div>
            <div style={{fontSize:'12px', fontWeight:500, marginTop:'4px'}}>再掃一份</div>
          </button>
          <button className="card" style={{padding:'14px', textAlign:'center', cursor:'pointer'}} onClick={() => {store.resetScan(); store.mSetTab('history');}}>
            <div style={{fontSize:'26px'}}>🕒</div>
            <div style={{fontSize:'12px', fontWeight:500, marginTop:'4px'}}>看歷史</div>
          </button>
        </div>
      </div>
    </>
  );
}

// ─── TOOLS LIST ────────────────────────────────────────────
function MTools(){
  const [, store] = window.useStore();
  const tools = [
    {id:'image', ic:'🖼️', label:'圖片工具', sub:'縮放 · 轉檔 · 壓縮 · 浮水印'},
    {id:'pdf', ic:'📕', label:'PDF 工具', sub:'合併 · 浮水印 · 加密'},
    {id:'convert', ic:'🔄', label:'文件轉檔', sub:'Word · PDF · Markdown'},
    {id:'gif', ic:'🎞️', label:'GIF 製作', sub:'圖片序列 → 動畫'},
    {id:'video', ic:'🎬', label:'影片工具', sub:'合併 · 轉 GIF · 壓縮'},
    {id:'rename', ic:'✏️', label:'批次改名', sub:'前後綴 · 取代 · 編號'},
  ];
  return (
    <>
      <MHeader title="工具箱" subt="輔助工具"/>
      <div className="m-body">
        <div className="col" style={{gap:'8px'}}>
          {tools.map(t => (
            <div key={t.id} className="card" style={{padding:'14px 16px', cursor:'pointer'}} onClick={() => store.mGoto('tool-' + t.id)}>
              <div className="row">
                <div style={{fontSize:'28px', width:'42px'}}>{t.ic}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:'14px', fontWeight:600}}>{t.label}</div>
                  <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'2px'}}>{t.sub}</div>
                </div>
                <div style={{fontSize:'18px', color:'var(--ink-4)'}}>›</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── HISTORY ──────────────────────────────────────────────
function MHistory(){
  const [state] = window.useStore();
  return (
    <>
      <MHeader title="寄件歷史" subt={`${state.history.length} 筆紀錄`}/>
      <div className="m-body">
        <div className="row" style={{gap:'6px', marginBottom:'12px', overflowX:'auto'}}>
          <span className="chip on">全部</span>
          {Object.entries(window.docTypes).slice(0,4).map(([k,t]) => (
            <span key={k} className="chip">{t.icon} {t.label}</span>
          ))}
        </div>
        <div className="col" style={{gap:'8px'}}>
          {state.history.map(h => (
            <div key={h.id} className="card" style={{padding:'12px'}}>
              <div className="row between" style={{marginBottom:'6px'}}>
                <DocTypeBadge type={h.docType} confidence={h.confidence}/>
                <span style={{fontSize:'10px', color:'var(--ink-3)'}}>{h.sentAt}</span>
              </div>
              <div style={{fontSize:'13px', fontWeight:500, lineHeight:1.4}}>{h.subject}</div>
              <div className="row between" style={{marginTop:'6px'}}>
                <span style={{fontSize:'11px', color:'var(--ink-3)'}}>→ {h.recipient}</span>
                <span style={{fontSize:'10px', fontFamily:'var(--font-mono)', color:'var(--ink-3)'}}>{h.size}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── MORE / SETTINGS ──────────────────────────────────────
function MMore(){
  const [, store] = window.useStore();
  const items = [
    {ic:'👥', label:'聯絡人', sub:'管理收件人與群組', go:'contacts'},
    {ic:'⚙', label:'設定', sub:'寄件人資料 · SMTP', go:'settings'},
    {ic:'📊', label:'統計', sub:'使用量與分析'},
    {ic:'❓', label:'說明'},
    {ic:'ℹ', label:'關於 ScanMail+'},
  ];
  return (
    <>
      <MHeader title="更多"/>
      <div className="m-body">
        <div className="card mint" style={{padding:'14px', marginBottom:'14px'}}>
          <div className="row">
            <div style={{width:'48px', height:'48px', borderRadius:'50%', background:'var(--mint-3)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-hand)', fontSize:'24px', fontWeight:700}}>劉</div>
            <div>
              <div style={{fontSize:'14px', fontWeight:600}}>劉瑞弘</div>
              <div style={{fontSize:'11px', color:'var(--ink-3)'}}>副教授 · 智慧自動化系</div>
              <div style={{fontSize:'10px', color:'var(--mint-4)', fontFamily:'var(--font-mono)'}}>liu@ncut.edu.tw</div>
            </div>
          </div>
        </div>
        <div className="col" style={{gap:'6px'}}>
          {items.map((x,i) => (
            <div key={i} className="card" style={{padding:'12px 14px', cursor:'pointer'}} onClick={() => x.go && store.mGoto(x.go)}>
              <div className="row">
                <span style={{fontSize:'20px', width:'32px'}}>{x.ic}</span>
                <div style={{flex:1}}>
                  <div style={{fontSize:'13px', fontWeight:500}}>{x.label}</div>
                  {x.sub && <div style={{fontSize:'11px', color:'var(--ink-3)'}}>{x.sub}</div>}
                </div>
                <span style={{color:'var(--ink-4)'}}>›</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── CONTACTS ─────────────────────────────────────────────
function MContacts(){
  const [state, store] = window.useStore();
  return (
    <>
      <MHeader title="聯絡人" back actions={<button className="pill primary" style={{fontSize:'12px'}}>＋ 新增</button>}/>
      <div className="m-body">
        <div className="label" style={{marginBottom:'6px'}}>群組 ({state.groups.length})</div>
        <div className="row" style={{gap:'6px', marginBottom:'14px', overflowX:'auto', paddingBottom:'4px'}}>
          {state.groups.map(g => (
            <div key={g.id} className="card" style={{flex:'0 0 auto', padding:'10px 12px'}}>
              <div style={{fontSize:'12px', fontWeight:600}}>📋 {g.name}</div>
              <div style={{fontSize:'10px', color:'var(--ink-3)'}}>{g.memberIds.length} 人</div>
            </div>
          ))}
        </div>
        <div className="label" style={{marginBottom:'6px'}}>所有聯絡人 ({state.contacts.length})</div>
        <div className="col" style={{gap:'6px'}}>
          {[...state.contacts].sort((a,b) => b.freq - a.freq).map(c => (
            <ContactTile key={c.id} contact={c} onClick={() => {}} onFav={() => store.toggleFav(c.id)} compact/>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────
function MSettings(){
  return (
    <>
      <MHeader title="設定" back/>
      <div className="m-body">
        <div className="label" style={{marginBottom:'6px'}}>寄件人資料</div>
        <div className="card" style={{padding:'12px', marginBottom:'12px'}}>
          {[['姓名','劉瑞弘'],['職稱','副教授'],['單位','智慧自動化工程系'],['組織','國立勤益科技大學']].map(([k,v]) => (
            <div key={k} className="row between" style={{padding:'6px 0', borderBottom:'1px dashed var(--line-soft)'}}>
              <span style={{fontSize:'11px', color:'var(--ink-3)'}}>{k}</span>
              <span style={{fontSize:'13px'}}>{v}</span>
            </div>
          ))}
        </div>
        <div className="label" style={{marginBottom:'6px'}}>SMTP 設定</div>
        <div className="card" style={{padding:'12px'}}>
          {[['SMTP Host','smtp.gmail.com'],['Port','587'],['帳號','liu@ncut.edu.tw'],['密碼','••••••••']].map(([k,v]) => (
            <div key={k} className="row between" style={{padding:'6px 0', borderBottom:'1px dashed var(--line-soft)'}}>
              <span style={{fontSize:'11px', color:'var(--ink-3)'}}>{k}</span>
              <span style={{fontSize:'13px', fontFamily:'var(--font-mono)'}}>{v}</span>
            </div>
          ))}
        </div>
        <div style={{marginTop:'12px'}}>
          <button className="btn primary" style={{width:'100%'}}>💾 儲存設定</button>
        </div>
      </div>
    </>
  );
}

// ─── BATCH TOOLS (mobile) ──────────────────────────────────
function MToolShell({ title, icon, actions, children }){
  return (
    <>
      <MHeader title={title} back subt={icon}/>
      <div className="m-body">{children}</div>
    </>
  );
}

function MToolImage(){
  const [action, setAction] = mUseState('resize');
  const actions = [{id:'resize',i:'📐',l:'縮放'},{id:'convert',i:'🔄',l:'轉檔'},{id:'compress',i:'📦',l:'壓縮'},{id:'watermark',i:'💧',l:'浮水印'}];
  return (
    <MToolShell title="圖片工具">
      <div className="row" style={{gap:'6px', marginBottom:'14px', overflowX:'auto', paddingBottom:'4px'}}>
        {actions.map(a => (
          <button key={a.id} className={`chip ${action===a.id?'on':''}`} onClick={() => setAction(a.id)} style={{flexShrink:0}}>
            {a.i} {a.l}
          </button>
        ))}
      </div>
      <div className="card dash" style={{padding:'28px 16px', textAlign:'center', marginBottom:'12px', background:'var(--paper-2)', cursor:'pointer'}}>
        <div style={{fontSize:'32px', opacity:0.4}}>📁</div>
        <div className="hand" style={{fontSize:'20px', marginTop:'6px'}}>拖放或選擇圖片</div>
        <div style={{fontSize:'11px', color:'var(--ink-3)'}}>JPG · PNG · WebP · 最多 50 個</div>
      </div>
      <div className="card fill" style={{padding:'14px', marginBottom:'12px'}}>
        <div className="label" style={{marginBottom:'8px'}}>{actions.find(a=>a.id===action).l}設定</div>
        {action === 'resize' && (
          <div className="grid-2">
            <div><div className="field-label">寬度</div><input className="input" defaultValue="800"/></div>
            <div><div className="field-label">高度</div><input className="input" defaultValue="600"/></div>
            <div style={{gridColumn:'1/-1'}}>
              <div className="field-label">模式</div>
              <div className="row" style={{gap:'4px'}}>
                <span className="chip on">等比</span><span className="chip">裁切</span><span className="chip">拉伸</span>
              </div>
            </div>
          </div>
        )}
        {action === 'convert' && (<div><div className="field-label">輸出格式</div><div className="row" style={{gap:'4px'}}>{['PNG','JPG','WebP','BMP'].map((f,i) => <span key={f} className={`chip ${i===0?'on':''}`}>{f}</span>)}</div></div>)}
        {action === 'compress' && (<div><div className="field-label">品質 70%</div><input type="range" className="slider" defaultValue="70"/></div>)}
        {action === 'watermark' && (<><div className="field-label">文字</div><input className="input" defaultValue="CONFIDENTIAL"/></>)}
      </div>
      <button className="btn primary" style={{width:'100%'}}>⚡ 開始處理</button>
    </MToolShell>
  );
}

function MToolPdf(){
  const [action, setAction] = mUseState('merge');
  const actions = [{id:'merge',i:'📎',l:'合併'},{id:'watermark',i:'💧',l:'浮水印'},{id:'protect',i:'🔒',l:'加密'}];
  return (
    <MToolShell title="PDF 工具">
      <div className="row" style={{gap:'6px', marginBottom:'14px'}}>
        {actions.map(a => <button key={a.id} className={`chip ${action===a.id?'on':''}`} onClick={() => setAction(a.id)}>{a.i} {a.l}</button>)}
      </div>
      <div className="card dash" style={{padding:'28px 16px', textAlign:'center', marginBottom:'12px', background:'var(--paper-2)'}}>
        <div style={{fontSize:'32px'}}>📕</div>
        <div className="hand" style={{fontSize:'20px', marginTop:'6px'}}>拖放 PDF 檔案</div>
      </div>
      <button className="btn primary" style={{width:'100%'}}>⚡ 處理 PDF</button>
    </MToolShell>
  );
}

function MToolConvert(){
  const convs = [{f:'Word',t:'PDF'},{f:'PDF',t:'Word'},{f:'MD',t:'PDF'},{f:'MD',t:'Word'},{f:'Word',t:'MD'}];
  const [sel, setSel] = mUseState(0);
  return (
    <MToolShell title="文件轉檔">
      <div className="label" style={{marginBottom:'6px'}}>選擇轉換方向</div>
      <div className="col" style={{gap:'6px', marginBottom:'14px'}}>
        {convs.map((c,i) => (
          <div key={i} onClick={() => setSel(i)} className="card" style={{padding:'12px', cursor:'pointer', background:sel===i?'var(--mint-wash)':'var(--paper)', borderColor:sel===i?'var(--mint-3)':'var(--line-soft)'}}>
            <div className="row" style={{justifyContent:'center', gap:'14px'}}>
              <span className="hand" style={{fontSize:'22px', fontWeight:600}}>{c.f}</span>
              <span style={{color:'var(--mint-3)'}}>→</span>
              <span className="hand" style={{fontSize:'22px', fontWeight:600}}>{c.t}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="card dash" style={{padding:'22px 12px', textAlign:'center'}}>
        <div style={{fontSize:'28px'}}>🔄</div>
        <div style={{fontSize:'12px', marginTop:'4px'}}>上傳 .{convs[sel].f.toLowerCase()} 檔案</div>
      </div>
    </MToolShell>
  );
}

function MToolGif(){
  return (
    <MToolShell title="GIF 製作">
      <div className="card dash" style={{padding:'28px 16px', textAlign:'center', marginBottom:'12px'}}>
        <div style={{fontSize:'32px'}}>🎞️</div>
        <div className="hand" style={{fontSize:'20px', marginTop:'6px'}}>拖放多張圖片</div>
        <div style={{fontSize:'11px', color:'var(--ink-3)'}}>依順序產生 GIF 動畫</div>
      </div>
      <div className="card fill" style={{padding:'14px'}}>
        <div className="grid-2">
          <div><div className="field-label">每幀 ms</div><input className="input" defaultValue="500"/></div>
          <div><div className="field-label">寬度</div><input className="input" defaultValue="auto"/></div>
        </div>
      </div>
      <button className="btn primary" style={{width:'100%', marginTop:'12px'}}>⚡ 產生 GIF</button>
    </MToolShell>
  );
}

function MToolVideo(){
  const [action, setAction] = mUseState('merge');
  return (
    <MToolShell title="影片工具">
      <div className="row" style={{gap:'6px', marginBottom:'14px'}}>
        {['合併','轉GIF','壓縮'].map((l,i) => <button key={l} className={`chip ${i===0 && action==='merge'?'on':''}`}>{l}</button>)}
      </div>
      <div className="card dash" style={{padding:'28px 16px', textAlign:'center'}}>
        <div style={{fontSize:'32px'}}>🎬</div>
        <div className="hand" style={{fontSize:'18px', marginTop:'6px'}}>拖放影片檔案</div>
        <div style={{fontSize:'10px', color:'var(--ink-3)', marginTop:'2px'}}>MP4 · MOV · WebM (≤200MB)</div>
      </div>
    </MToolShell>
  );
}

function MToolRename(){
  return (
    <MToolShell title="批次改名">
      <div className="card dash" style={{padding:'22px', textAlign:'center', marginBottom:'12px'}}>
        <div style={{fontSize:'28px'}}>📁</div>
        <div className="hand" style={{fontSize:'18px', marginTop:'6px'}}>拖放任意檔案</div>
      </div>
      <div className="card fill" style={{padding:'14px'}}>
        <div className="field-label">前綴</div>
        <input className="input" placeholder="例: 2026_"/>
        <div className="field-label" style={{marginTop:'8px'}}>流水編號</div>
        <div className="row"><input className="input" defaultValue="001" style={{flex:1}}/><span className="chip">位數 3</span></div>
      </div>
    </MToolShell>
  );
}

Object.assign(window, { MobileShell });
