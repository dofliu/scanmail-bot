/* Global state + helpers (vanilla, exposed on window) */
(function(){
  // Initial demo data
  const initialContacts = [
    { id:1, name:'王經理', email:'wang@ncut.edu.tw', dept:'行政部', title:'經理', freq:24, fav:true },
    { id:2, name:'林秘書', email:'lin@ncut.edu.tw', dept:'校長室', title:'秘書', freq:18, fav:true },
    { id:3, name:'陳主任', email:'chen@ncut.edu.tw', dept:'智慧自動化系', title:'主任', freq:12, fav:false },
    { id:4, name:'張教授', email:'chang@ncut.edu.tw', dept:'電機系', title:'教授', freq:8, fav:false },
    { id:5, name:'黃老師', email:'huang@ncut.edu.tw', dept:'資工系', title:'副教授', freq:6, fav:false },
    { id:6, name:'李組長', email:'li@ncut.edu.tw', dept:'會計室', title:'組長', freq:4, fav:false },
    { id:7, name:'周助理', email:'chou@ncut.edu.tw', dept:'系辦', title:'助理', freq:14, fav:true },
    { id:8, name:'吳教授', email:'wu@ncut.edu.tw', dept:'機械系', title:'教授', freq:3, fav:false },
  ];

  const initialGroups = [
    { id:1, name:'系務會議', memberIds:[1,2,3,5,8] },
    { id:2, name:'研究團隊', memberIds:[3,4,5] },
    { id:3, name:'行政群組', memberIds:[1,2,6,7] },
  ];

  const initialHistory = [
    { id:1, recipient:'王經理', email:'wang@ncut.edu.tw', subject:'[公文] 離岸風電審查會議改期通知', docType:'official', docLabel:'公文', filename:'公文_離岸風電審查_20260418.pdf', size:'412 KB', sentAt:'今天 09:12', confidence:0.98 },
    { id:2, recipient:'林秘書', email:'lin@ncut.edu.tw', subject:'[報告] 本月系務進度報告', docType:'report', docLabel:'報告', filename:'報告_系務進度_20260418.pdf', size:'823 KB', sentAt:'昨天 16:34', confidence:0.94 },
    { id:3, recipient:'陳主任 + 4 人', email:'chen@ncut.edu.tw', subject:'[收據] 耗材採購收據', docType:'receipt', docLabel:'收據', filename:'收據_耗材採購_20260417.pdf', size:'156 KB', sentAt:'昨天 10:22', confidence:0.89 },
    { id:4, recipient:'張教授', email:'chang@ncut.edu.tw', subject:'[信函] 邀請函 — 產學合作', docType:'letter', docLabel:'信函', filename:'信函_產學合作_20260416.pdf', size:'234 KB', sentAt:'2 天前', confidence:0.92 },
    { id:5, recipient:'黃老師', email:'huang@ncut.edu.tw', subject:'[表單] 請購單 #2026-0342', docType:'form', docLabel:'表單', filename:'表單_請購單_20260415.pdf', size:'178 KB', sentAt:'4 天前', confidence:0.96 },
  ];

  const docTypes = {
    official: { label:'公文', icon:'📋', color:'#4ea07c' },
    receipt:  { label:'收據', icon:'🧾', color:'#c48a3a' },
    report:   { label:'報告', icon:'📊', color:'#6b8aa3' },
    contract: { label:'合約', icon:'📜', color:'#b25a4a' },
    letter:   { label:'信函', icon:'✉️', color:'#8aa377' },
    exam:     { label:'考卷', icon:'📝', color:'#a5828f' },
    form:     { label:'表單', icon:'📑', color:'#7d7a95' },
    other:    { label:'其他', icon:'📎', color:'#6b766e' },
  };

  const filters = [
    { id:'auto',      label:'自動',    icon:'🪄' },
    { id:'scan',      label:'專業掃描', icon:'🖨' },
    { id:'color_doc', label:'彩色公文', icon:'🔴' },
    { id:'document',  label:'文件',    icon:'📄' },
    { id:'enhance',   label:'增強',    icon:'🔆' },
    { id:'bw',        label:'黑白',    icon:'◼' },
    { id:'original',  label:'原圖',    icon:'🖼' },
  ];

  // AI mock
  function mockAI(contact){
    const samples = [
      { docType:'official', subject:'[公文] 離岸風電審查會議改期通知',
        body:`${contact ? contact.name : '收件人'}您好，\n\n檢附經濟部產業發展署來函，有關離岸風電審查會議改期事宜，原訂於 4/25 之會議，因主席公務，改期至 5/02（週四）下午 2:00 於本校行政大樓 3F 會議室召開。\n\n請查收附件公文並確認出席。\n\n劉瑞弘 敬上`,
        filename:'公文_離岸風電審查改期_20260419.pdf', confidence:0.98 },
      { docType:'receipt', subject:'[收據] 耗材採購收據 — 3 月份',
        body:`${contact ? contact.name : '收件人'}您好，\n\n檢附 3 月份實驗室耗材採購收據，共 NT$12,340。請惠予核銷。\n\n謝謝\n劉瑞弘 敬上`,
        filename:'收據_耗材採購_20260419.pdf', confidence:0.94 },
      { docType:'report', subject:'[報告] 系務會議進度報告',
        body:`${contact ? contact.name : '收件人'}您好，\n\n附上本週系務會議的進度報告，包含預算執行、招生狀況與實驗室建置。\n\n敬請指教。\n劉瑞弘 敬上`,
        filename:'報告_系務進度_20260419.pdf', confidence:0.91 },
    ];
    return samples[Math.floor(Math.random() * samples.length)];
  }

  // Store
  const listeners = new Set();
  const state = {
    view: 'mobile',           // mobile | desktop
    density: 'default',
    tweaksOpen: false,

    // Mobile nav
    mTab: 'home',             // home | scan | tools | history | more
    mStack: [],               // screen stack above tab
    // Desktop nav
    dTool: 'scanmail',
    dSubTool: null,
    dView: 'dashboard',       // dashboard | scan | contacts | history | tools | settings

    // Scan flow shared
    scanStep: 0,              // 0 = idle, 1 = capture, 2 = crop, 3 = filter, 4 = contact, 5 = ai, 6 = preview, 7 = success
    pages: [],                // [{id, filter, rotation, cropped}]
    currentPageId: null,
    selectedFilter: 'auto',
    selectedContactIds: [],
    aiResult: null,
    aiLoading: false,
    editingPreview: false,

    contacts: initialContacts,
    groups: initialGroups,
    history: initialHistory,

    // Batch tools
    imgFiles: [{id:1, name:'IMG_0419_01.jpg', size:'2.4 MB', dim:'3024×4032', status:'ready'},
               {id:2, name:'收據_scan.png', size:'1.1 MB', dim:'1920×2560', status:'ready'},
               {id:3, name:'會議白板.jpg', size:'4.8 MB', dim:'4032×3024', status:'ready'}],
    pdfFiles: [],
    docFiles: [],

    toasts: [],

    docTypes, filters,
  };

  let nextId = 100;

  const store = {
    get: () => state,
    subscribe(fn){ listeners.add(fn); return () => listeners.delete(fn); },
    set(patch){
      Object.assign(state, patch);
      listeners.forEach(fn => fn(state));
    },
    toast(msg, kind='ok'){
      const id = nextId++;
      state.toasts = [...state.toasts, { id, msg, kind }];
      listeners.forEach(fn => fn(state));
      setTimeout(() => {
        state.toasts = state.toasts.filter(t => t.id !== id);
        listeners.forEach(fn => fn(state));
      }, 2400);
    },
    // Navigation
    mGoto(screen){
      state.mStack = [...state.mStack, screen];
      listeners.forEach(fn => fn(state));
    },
    mBack(){
      state.mStack = state.mStack.slice(0, -1);
      listeners.forEach(fn => fn(state));
    },
    mSetTab(tab){
      state.mTab = tab;
      state.mStack = [];
      listeners.forEach(fn => fn(state));
    },
    dSetView(view){
      state.dView = view;
      listeners.forEach(fn => fn(state));
    },
    setView(view){
      state.view = view;
      listeners.forEach(fn => fn(state));
    },
    // Scan flow
    startScan(){
      state.pages = [];
      state.currentPageId = null;
      state.scanStep = 1;
      state.selectedContactIds = [];
      state.aiResult = null;
      listeners.forEach(fn => fn(state));
    },
    addPage(){
      const page = {
        id: nextId++,
        filter: 'auto',
        rotation: 0,
        cropped: true,
        thumb: 'mock',
      };
      state.pages = [...state.pages, page];
      state.currentPageId = page.id;
      listeners.forEach(fn => fn(state));
      return page;
    },
    setFilter(filter){
      state.selectedFilter = filter;
      state.pages = state.pages.map(p => p.id === state.currentPageId ? {...p, filter} : p);
      listeners.forEach(fn => fn(state));
    },
    applyFilterToAll(filter){
      state.selectedFilter = filter;
      state.pages = state.pages.map(p => ({...p, filter}));
      listeners.forEach(fn => fn(state));
    },
    removePage(id){
      state.pages = state.pages.filter(p => p.id !== id);
      if(state.currentPageId === id){
        state.currentPageId = state.pages[0]?.id || null;
      }
      listeners.forEach(fn => fn(state));
    },
    setCurrentPage(id){
      state.currentPageId = id;
      listeners.forEach(fn => fn(state));
    },
    toggleContact(id){
      const s = new Set(state.selectedContactIds);
      if(s.has(id)) s.delete(id); else s.add(id);
      state.selectedContactIds = [...s];
      listeners.forEach(fn => fn(state));
    },
    selectGroup(groupId){
      const g = state.groups.find(g => g.id === groupId);
      if(!g) return;
      state.selectedContactIds = [...g.memberIds];
      listeners.forEach(fn => fn(state));
    },
    runAI(){
      state.aiLoading = true;
      state.aiResult = null;
      listeners.forEach(fn => fn(state));
      setTimeout(() => {
        const contact = state.contacts.find(c => c.id === state.selectedContactIds[0]);
        state.aiResult = mockAI(contact);
        state.aiLoading = false;
        listeners.forEach(fn => fn(state));
      }, 1600);
    },
    sendEmail(){
      state.scanStep = 7;
      // push into history
      const contact = state.contacts.find(c => c.id === state.selectedContactIds[0]);
      const recip = state.selectedContactIds.length > 1
        ? `${contact?.name || ''} + ${state.selectedContactIds.length - 1} 人`
        : contact?.name || '';
      state.history = [{
        id: nextId++,
        recipient: recip,
        email: contact?.email || '',
        subject: state.aiResult?.subject || '',
        docType: state.aiResult?.docType || 'other',
        docLabel: docTypes[state.aiResult?.docType]?.label || '其他',
        filename: state.aiResult?.filename || '',
        size: '~420 KB',
        sentAt: '剛剛',
        confidence: state.aiResult?.confidence || 0,
      }, ...state.history];
      listeners.forEach(fn => fn(state));
    },
    resetScan(){
      state.pages = [];
      state.currentPageId = null;
      state.scanStep = 0;
      state.selectedContactIds = [];
      state.aiResult = null;
      state.selectedFilter = 'auto';
      listeners.forEach(fn => fn(state));
    },
    addContact(c){
      const id = nextId++;
      state.contacts = [...state.contacts, { id, freq:0, fav:false, ...c }];
      listeners.forEach(fn => fn(state));
    },
    removeContact(id){
      state.contacts = state.contacts.filter(c => c.id !== id);
      state.selectedContactIds = state.selectedContactIds.filter(x => x !== id);
      listeners.forEach(fn => fn(state));
    },
    toggleFav(id){
      state.contacts = state.contacts.map(c => c.id === id ? {...c, fav:!c.fav} : c);
      listeners.forEach(fn => fn(state));
    },
  };

  // useStore hook (to be used inside React component files)
  function useStore(){
    const [, force] = React.useReducer(x => x+1, 0);
    React.useEffect(() => store.subscribe(force), []);
    return [state, store];
  }

  window.SMStore = store;
  window.useStore = useStore;
  window.docTypes = docTypes;
  window.filterList = filters;
})();
