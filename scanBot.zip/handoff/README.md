# ScanMail+ Hi-Fi UI — 覆蓋替換包

結構對應原專案的 `scanmail_bot/static/`，可直接覆蓋。

## 檔案結構

```
handoff/
└── static/
    ├── index.html           ← 新 UI 入口
    ├── css/
    │   └── palette.css      ← 設計系統（粉綠紙感 + 手寫字型）
    └── js/
        ├── store.js         ← 前端狀態 store（React hook）
        ├── atoms.jsx        ← 共用 UI 元件
        ├── mobile.jsx       ← 手機版所有畫面
        └── desktop.jsx      ← 桌面版所有畫面
```

## 覆蓋步驟

1. **備份**原 `scanmail_bot/static/`
2. 將此資料夾 `handoff/static/` 的內容複製覆蓋到 `scanmail_bot/static/`
3. 原有的 `js/app.js`, `js/scanmail.js`, `js/batch-rename.js` 等可先保留（未引用）
4. 重啟 server: `uvicorn main:app --reload`

## ⚠ 注意事項

**UI 為原型，API 呼叫皆為前端 mock**，需將原檔的 fetch 邏輯接回：

- `store.runAI()` → 接 `POST /api/gemini/analyze`
- `store.sendEmail()` → 接 `POST /api/scanmail/send`
- 批次工具 → 接 `/api/image`, `/api/pdf`, `/api/video` 等

字型從 Google Fonts CDN 載入，離線環境需改本地託管。

## 設計系統

- 配色：粉綠紙感（mint on paper）
- 字型：Caveat + Architects Daughter + Noto Sans TC
- Tweaks：視圖模式、主色、紙色、密度皆可切換

2026/04/19
